// Dashboard
import Root from './view/Root';
import './App.css';

function App() {
  return (
    <Root />
  );
}

export default App;
