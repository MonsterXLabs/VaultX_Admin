const url = 'https://example.com'
export default url;